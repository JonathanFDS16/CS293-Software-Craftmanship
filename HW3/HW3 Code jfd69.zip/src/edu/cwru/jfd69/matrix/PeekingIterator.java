package edu.cwru.jfd69.matrix;

import java.util.Iterator;
import java.util.Optional;

/**
 * PeekingIterator
 * Class provides same functionality as an Iterator, but with the possibility to peek at the next element
 * without advancing the iterator.
 * @param <T> The type to be iterated.
 */
public final class PeekingIterator<T> implements Iterator<T> {

    private final Iterator<T> it;

    private Optional<T> next;

    private PeekingIterator(Iterator<T> it) {
        this.it = it;
        next = Optional.of(it.next());
    }

    /**
     * Creates a new instance of PeekingIterator from an iterator.
     * @param iterator the iterator of S
     * @return a new instance of PeekingIterator
     * @param <S> the element to be iterated by the PeekingIterator
     */
    public static <S> PeekingIterator<S> from(Iterator<S> iterator) {
        if (iterator == null) throw new NullPointerException("Invalid null iterator");

        return new PeekingIterator<>(iterator);
    }

    /**
     * Creates a new instance of PeekingIterator from an iterator.
     * @param iterable the iterable instance S
     * @return a new instance of PeekingIterator
     * @param <S> the element to be iterated by the PeekingIterator
     */
    public static <S> PeekingIterator<S> from(Iterable<S> iterable) {
        if (iterable == null) throw new NullPointerException("Invalid null iterable");

        return new PeekingIterator<>(iterable.iterator());
    }

    /**
     * Peek to next element of the iterator without advancing the iterator.
     * @return Return an Optional of the next element.
     */
    public Optional<T> peek() {
        return next;
    }

    /**
     * Return the next element without advancing the iterator.
     * @return Return the next element
     */
    public T element() {
        return next.get();
    }


    @Override
    public boolean hasNext() {
        return next.isPresent();
    }

    @Override
    public T next() {
        T save = next.get();
        if (it.hasNext())
            next = Optional.of(it.next());
        else next = Optional.empty();
        return save;
    }
}
